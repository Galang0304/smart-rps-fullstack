
import React from 'react';

interface TaskPlanProps {
  taskNumber: number;
}

const TaskPlan: React.FC<TaskPlanProps> = ({ taskNumber }) => {
  return (
    <div className="a4-page text-xs">
      <h2 className="font-bold text-lg mb-4 uppercase">Rencana Tugas</h2>
      <h3 className="font-bold text-md mb-4 uppercase">{taskNumber}. Rencana Tugas {taskNumber}</h3>
      
      <table>
        <tbody>
          <tr>
            <td rowSpan={2} className="w-24 text-center">
               <div className="border border-blue-400 rounded-full w-16 h-16 mx-auto flex items-center justify-center p-1">
                 <img src="https://unismuh.ac.id/wp-content/uploads/2021/04/Logo-Unismuh-Makassar-300x300.png" alt="Logo" className="w-full" />
              </div>
            </td>
            <td colSpan={2} className="header-blue uppercase py-2">
              Perguruan Tinggi<br/>
              Fakultas<br/>
              Program Studi
            </td>
          </tr>
          <tr className="header-blue font-bold py-1">
            <td colSpan={2}>RENCANA TUGAS MAHASISWA</td>
          </tr>
          <tr>
            <td rowSpan={4} className="label-cell uppercase p-2">Identitas Mata Kuliah</td>
            <td className="w-32 label-cell">Nama MK</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">Kode</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">Semester</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">SKS</td>
            <td></td>
          </tr>
          <tr>
            <td rowSpan={2} className="label-cell uppercase p-2">Sub-CPMK & Indikator</td>
            <td className="label-cell">Sub-CPMK</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">Indikator</td>
            <td></td>
          </tr>
          <tr>
            <td rowSpan={4} className="label-cell uppercase p-2">Rencana Tugas</td>
            <td className="label-cell">Judul Tugas</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">Batas Waktu</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">Petunjuk Pengerjaan Tugas</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">Luaran Tugas</td>
            <td></td>
          </tr>
          <tr>
            <td rowSpan={3} className="label-cell uppercase p-2">Penilaian</td>
            <td className="label-cell">Kriteria</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">Teknik Penilaian</td>
            <td></td>
          </tr>
          <tr>
            <td className="label-cell">Bobot (%)</td>
            <td></td>
          </tr>
          <tr className="h-12">
            <td className="label-cell uppercase p-2">Daftar Rujukan</td>
            <td colSpan={2}></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default TaskPlan;
