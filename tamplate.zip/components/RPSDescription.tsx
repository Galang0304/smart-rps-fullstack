
import React from 'react';

const RPSDescription: React.FC = () => {
  return (
    <div className="a4-page text-xs">
      <h2 className="text-center font-bold text-xl mb-4 uppercase">Deskripsi RPS</h2>
      
      <table>
        <tbody>
          <tr>
            <td rowSpan={2} className="w-24 text-center">
              {/* Logo Placeholder */}
              <div className="border border-blue-400 rounded-full w-16 h-16 mx-auto flex items-center justify-center p-1">
                 <img src="https://unismuh.ac.id/wp-content/uploads/2021/04/Logo-Unismuh-Makassar-300x300.png" alt="Logo" className="w-full" />
              </div>
            </td>
            <td colSpan={6} className="header-blue uppercase text-sm py-2">
              Perguruan Tinggi<br/>
              Fakultas<br/>
              Program Studi
            </td>
          </tr>
          <tr className="font-bold text-center uppercase">
            <td>Nama Mata Kuliah</td>
            <td>Kode MK</td>
            <td>Rumpun MK</td>
            <td>Bobot (SKS)</td>
            <td>Semester</td>
            <td>Tgl Penyusunan</td>
          </tr>
          <tr className="h-10 text-center">
            <td></td>
            <td></td>
            <td></td>
            <td className="p-0">
               <div className="border-b h-1/2 flex items-center justify-center">T=..</div>
               <div className="h-1/2 flex items-center justify-center">P=..</div>
            </td>
            <td></td>
            <td>.....</td>
          </tr>
          <tr className="header-blue uppercase">
            <td colSpan={2}>UPM Fakultas</td>
            <td colSpan={2}>Nama Penyusun RPS</td>
            <td>Koordinator RMK</td>
            <td colSpan={2}>Ka Prodi</td>
          </tr>
          <tr className="h-12 text-center align-bottom text-black font-semibold">
            <td colSpan={2}>xxxxx</td>
            <td colSpan={2}>xxxxx</td>
            <td>
              <div className="text-black text-[7pt] font-normal mb-1">Jika Ada</div>
              xxxxx
            </td>
            <td colSpan={2}>xxxxx</td>
          </tr>
          <tr>
            <td rowSpan={13} className="label-cell uppercase align-top p-2 w-32">
              CAPAIAN PEMBELAJARAN (CPL – CPMK – Sub CPMK)
            </td>
            <td colSpan={6} className="label-cell uppercase text-[9pt]">Capaian Pembelajaran Lulusan yang dibebankan pada MK (CPL)</td>
          </tr>
          <tr>
            <td className="w-16 label-cell">CPL1 (S)</td>
            <td colSpan={5}></td>
          </tr>
          <tr>
            <td className="label-cell">CPL n</td>
            <td colSpan={5}></td>
          </tr>
          <tr>
            <td colSpan={6} className="label-cell uppercase text-[9pt]">Capain Pembelajaran Mata Kuliah (CPMK)</td>
          </tr>
          <tr>
            <td className="label-cell">CPMK1</td>
            <td colSpan={5}></td>
          </tr>
          <tr>
            <td className="label-cell">CPMK n</td>
            <td colSpan={5}></td>
          </tr>
          <tr>
            <td colSpan={6} className="label-cell uppercase text-[9pt]">Kemampuan Akhir Tiap Tahapan Pembelajaran (Sub-CPMK)</td>
          </tr>
          <tr>
            <td className="label-cell">Sub-CPMK1</td>
            <td colSpan={5}></td>
          </tr>
          <tr>
            <td className="label-cell">Sub-CPMK n</td>
            <td colSpan={5}></td>
          </tr>
          <tr className="header-blue text-[8pt]">
             <td>Korelasi</td>
             <td>Sub-CPMK1</td>
             <td>Sub-CPMK2</td>
             <td>Sub-CPMK3</td>
             <td>Sub-CPMK4</td>
             <td>Sub-CPMK5</td>
          </tr>
          <tr>
             <td className="label-cell">CPMK1</td>
             <td></td><td></td><td></td><td></td><td></td>
          </tr>
          <tr>
             <td className="label-cell">CPMK n</td>
             <td></td><td></td><td></td><td></td><td></td>
          </tr>
          <tr>
            <td className="label-cell uppercase p-2 w-32">Deskripsi Mata Kuliah</td>
            <td colSpan={6} className="h-24 align-top py-2">
              …………………………………………………………………………..<br/>
              …………………………………………………………………………..<br/>
              …………………………………………………………………………..
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default RPSDescription;
