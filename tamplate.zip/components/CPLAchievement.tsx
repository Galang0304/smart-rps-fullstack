
import React from 'react';

const CPLAchievement: React.FC = () => {
  const weeks = ["1", "2 – 4", "5 – 6", "7 – 8", "9 – 11", "12 – 13", "14 – 16"];
  
  return (
    <div className="a4-page text-xs">
      <h2 className="text-center font-bold text-xl mb-12 uppercase">
        Analisis Ketercapaian CPL dan Bobot Penilaian
      </h2>
      
      <table>
        <thead className="header-blue uppercase text-[8pt]">
          <tr>
            <th className="w-16">Minggu Ke-</th>
            <th>CPL</th>
            <th>CPMK</th>
            <th>Sub-CPMK</th>
            <th>Topik Materi</th>
            <th>Jenis Assessmen</th>
            <th>Bobot (%)</th>
          </tr>
        </thead>
        <tbody>
          {weeks.map((week, idx) => (
            <tr key={idx} className="h-10">
              <td className="text-center">{week}</td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CPLAchievement;
