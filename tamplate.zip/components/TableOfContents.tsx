
import React from 'react';

const TableOfContents: React.FC = () => {
  const items = [
    { text: 'RENCANA PEMBELAJARAN SEMESTER', page: '1' },
    { text: 'DAFTAR ISI', page: '2' },
    { text: '1. TOPIK 1 / PERTEMUAN 1 *', page: '6', indent: true },
    { text: '2. TOPIK 2 / PERTEMUAN 2', page: 'Error! Bookmark not defined.', indent: true },
    { text: '3. TOPIK 3 / PERTEMUAN 3 DAN SETERUSNYA', page: 'Error! Bookmark not defined.', indent: true },
    { text: 'RENCANA TUGAS PROYEK', page: '7' },
    { text: 'PENILAIAN DAN KETERCAPAIAN CPL', page: '10' },
    { text: 'PENILAIAN DAN SKALA PENILAIAN', page: '11' },
  ];

  return (
    <div className="a4-page">
      <h2 className="text-center font-bold text-xl mb-12 uppercase">Daftar Isi</h2>
      
      <div className="flex flex-col gap-1 w-full text-xs uppercase">
        {items.map((item, idx) => (
          <div key={idx} className={`flex items-end ${item.indent ? 'pl-8' : ''}`}>
            <span className="flex-shrink-0">{item.text}</span>
            <div className="flex-grow border-b border-dotted border-black mb-1 mx-1"></div>
            <span className="flex-shrink-0">{item.page}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TableOfContents;
