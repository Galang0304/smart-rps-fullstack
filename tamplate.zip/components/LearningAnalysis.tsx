
import React from 'react';

const LearningAnalysis: React.FC = () => {
  return (
    <div className="a4-page">
      <h2 className="text-center font-bold text-xl mb-8 uppercase">Analisis Pembelajaran</h2>
      <p className="mb-4">Contoh:</p>
      
      <table className="mb-12 text-center text-xs">
        <thead className="bg-[#00AEEF]">
          <tr>
            <th rowSpan={2}>CPL</th>
            <th rowSpan={2}>CPMK</th>
            <th colSpan={7}>Sub-CPMK Ke-</th>
          </tr>
          <tr>
            <th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th><th>7</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td rowSpan={4}>CPL 1</td>
            <td>CPMK 1</td>
            <td>√</td><td>√</td><td>√</td><td>√</td><td></td><td></td><td></td>
          </tr>
          <tr>
            <td>CPMK 2</td>
            <td></td><td></td><td></td><td></td><td>√</td><td></td><td></td>
          </tr>
          <tr>
            <td>CPMK 3</td>
            <td></td><td></td><td></td><td></td><td></td><td>√</td><td></td>
          </tr>
          <tr>
            <td>CPMK 4</td>
            <td></td><td></td><td></td><td></td><td></td><td></td><td>√</td>
          </tr>
        </tbody>
      </table>

      {/* Simplified Flow Diagram representation */}
      <div className="relative mt-20 flex flex-col items-center space-y-4">
        <div className="flex items-center space-x-8">
           <div className="bg-blue-100 border border-blue-300 rounded-md px-4 py-2 text-[10pt] shadow-sm text-black">
             Hubungan CPL, CPMK, dan Sub-CPMK
           </div>
           <div className="text-black">←</div>
           <div className="bg-blue-100 border border-blue-300 rounded-md px-4 py-2 text-[10pt] text-black">CPL 1</div>
           <div className="text-black">←</div>
           
           <div className="flex flex-col space-y-4">
             {/* Branch 1 */}
             <div className="flex items-center space-x-2">
               <div className="bg-emerald-100 border border-emerald-300 rounded-md px-3 py-1 text-[9pt] text-black">CPMK 1</div>
               <div className="text-black">←</div>
               <div className="flex flex-col space-y-1">
                 <div className="bg-green-200 rounded-full px-4 py-1 text-[8pt] text-black">Sub-CPMK 1 (Kolom 3)</div>
                 <div className="bg-green-200 rounded-full px-4 py-1 text-[8pt] text-black">Sub-CPMK 2 (Kolom 4)</div>
                 <div className="bg-green-200 rounded-full px-4 py-1 text-[8pt] text-black">Sub-CPMK 3 (Kolom 5)</div>
                 <div className="bg-green-200 rounded-full px-4 py-1 text-[8pt] text-black">Sub-CPMK 4 (Kolom 6)</div>
               </div>
             </div>
             
             {/* Branch 2 */}
             <div className="flex items-center space-x-2">
               <div className="bg-emerald-100 border border-emerald-300 rounded-md px-3 py-1 text-[9pt] text-black">CPMK 2</div>
               <div className="text-black">←</div>
               <div className="bg-green-200 rounded-full px-4 py-1 text-[8pt] text-black">Sub-CPMK 2 (Kolom 4)</div>
             </div>

              {/* Branch 3 */}
              <div className="flex items-center space-x-2">
               <div className="bg-emerald-100 border border-emerald-300 rounded-md px-3 py-1 text-[9pt] text-black">CPMK 3</div>
               <div className="text-black">←</div>
               <div className="bg-green-200 rounded-full px-4 py-1 text-[8pt] text-black">Sub-CPMK 3 (Kolom 5)</div>
             </div>

              {/* Branch 4 */}
              <div className="flex items-center space-x-2">
               <div className="bg-emerald-100 border border-emerald-300 rounded-md px-3 py-1 text-[9pt] text-black">CPMK 4</div>
               <div className="text-black">←</div>
               <div className="bg-green-200 rounded-full px-4 py-1 text-[8pt] text-black">Sub-CPMK 4 (Kolom 6)</div>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default LearningAnalysis;
