
import React from 'react';

const RPSDescriptionPart2: React.FC = () => {
  return (
    <div className="a4-page text-xs">
      <table className="w-full">
        <tbody>
          <tr>
            <td rowSpan={2} className="w-24 text-center">
              <div className="border border-blue-400 rounded-full w-16 h-16 mx-auto flex items-center justify-center p-1">
                 <img src="https://unismuh.ac.id/wp-content/uploads/2021/04/Logo-Unismuh-Makassar-300x300.png" alt="Logo" className="w-full" />
              </div>
            </td>
            <td colSpan={2} className="header-blue uppercase text-sm py-4">
              Perguruan Tinggi<br/>
              Fakultas<br/>
              Program Studi
            </td>
          </tr>
          <tr>
            <td className="label-cell w-32 uppercase p-2">Bahan Kajian (Topik)</td>
            <td className="p-2 space-y-1">
              <div>1. ….</div>
              <div>2. ….</div>
              <div>3. ….</div>
              <div>4. ….</div>
              <div>5. dan seterusnya</div>
            </td>
          </tr>
          <tr>
            <td colSpan={2} className="label-cell uppercase p-2">Referensi</td>
            <td className="p-2 space-y-1">
              <div>1. ….</div>
              <div>2. ….</div>
              <div>3. ….</div>
              <div>dan seterusnya</div>
            </td>
          </tr>
          <tr>
            <td colSpan={2} className="label-cell uppercase p-2">Nama Dosen</td>
            <td></td>
          </tr>
          <tr>
            <td colSpan={2} className="label-cell uppercase p-2">Mata Kuliah Prsyarat</td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default RPSDescriptionPart2;
