
import React from 'react';

const CoverPage: React.FC = () => {
  return (
    <div className="a4-page flex flex-col items-center justify-start pt-12">
      <div className="text-sm tracking-widest mb-48">SAMPUL</div>
      
      <h1 className="text-xl font-bold text-center mb-2 uppercase">
        Rencana Pembelajaran Semester
      </h1>
      <h2 className="text-md font-bold text-center mb-12 uppercase italic">
        (Model Blended Learning – Type Flipped Learning)
      </h2>

      <div className="w-full max-w-lg border-t-2 border-blue-400 mt-4"></div>
      <div className="py-4 text-center">
        <span className="text-black font-bold text-lg uppercase">
          Mata Kuliah : …………………………………..
        </span>
      </div>
      <div className="w-full max-w-lg border-t-2 border-blue-400"></div>
    </div>
  );
};

export default CoverPage;
