
import React from 'react';

const GradingScale: React.FC = () => {
  const data = [
    { no: 1, interval: "90 – 100", letter: "A", weight: "4,00", desc: "Lulus" },
    { no: 2, interval: "85 – 89", letter: "A-", weight: "3,75", desc: "Lulus" },
    { no: 3, interval: "80 – 84", letter: "B+", weight: "3,50", desc: "Lulus" },
    { no: 4, interval: "75 – 79", letter: "B", weight: "3,00", desc: "Lulus" },
    { no: 5, interval: "70 – 74", letter: "B-", weight: "2,75", desc: "Lulus" },
    { no: 6, interval: "60 – 69", letter: "C", weight: "2,50", desc: "Lulus" },
    { no: 7, interval: "< 60", letter: "E", weight: "0", desc: "Tidak Lulus" },
  ];

  return (
    <div className="a4-page">
      <h2 className="text-center font-bold text-xl mb-8 uppercase">Skala Penilaian</h2>
      
      <div className="w-full flex justify-center mb-16">
        <table className="w-3/4 text-center">
          <thead className="header-blue uppercase">
            <tr>
              <th rowSpan={2}>No</th>
              <th colSpan={3}>Nilai</th>
              <th rowSpan={2}>Keterangan</th>
            </tr>
            <tr>
              <th>Interval</th>
              <th>Huruf</th>
              <th>Bobot</th>
            </tr>
          </thead>
          <tbody>
            {data.map((row) => (
              <tr key={row.no}>
                <td>{row.no}</td>
                <td>{row.interval}</td>
                <td>{row.letter}</td>
                <td>{row.weight}</td>
                <td>{row.desc}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-2 gap-8 mt-20 text-sm">
        <div className="space-y-16">
          <div className="space-y-1">
            <p>Penelaah</p>
            <p>Penjamin Mutu Program Studi</p>
          </div>
          <div className="space-y-1">
            <p>………………………</p>
            <p className="font-bold">NIDN.</p>
          </div>
        </div>

        <div className="space-y-16 text-right">
          <div className="space-y-1 text-left inline-block">
            <p>Penyusun RPS</p>
            <p>Koordinator Mata Kuliah</p>
          </div>
          <div className="space-y-1 text-left inline-block">
            <p>………………………</p>
            <p className="font-bold">NIDN.</p>
          </div>
        </div>
      </div>

      <div className="w-full flex flex-col items-center mt-20 space-y-16">
        <div className="text-center">
          <p>Disahkan oleh:</p>
          <p>Ketua Program Studi</p>
        </div>
        <div className="text-center">
          <p>………………………</p>
          <p className="font-bold">NIDN.</p>
        </div>
      </div>
    </div>
  );
};

export default GradingScale;
