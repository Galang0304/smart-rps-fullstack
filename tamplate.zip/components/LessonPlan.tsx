
import React from 'react';

const LessonPlan: React.FC = () => {
  return (
    <div className="a4-page text-[8pt]">
      <h2 className="text-center font-bold text-xl mb-8 uppercase">Rencana Pembelajaran</h2>
      
      <table className="w-full">
        <thead className="header-blue uppercase">
          <tr>
            <th className="w-10">Mg Ke-</th>
            <th className="w-32">Kemampuan Akhir Tiap Tahapan (Sub-CPMK)</th>
            <th>Indikator</th>
            <th>Topik & Sub-Topik Materi</th>
            <th>Metode Pembelajaran (Skema Blended Learning)</th>
            <th className="w-16">Waktu (Menit)</th>
            <th colSpan={2}>Penilaian</th>
          </tr>
          <tr className="text-[7pt]">
            <th colSpan={6}></th>
            <th>Teknik & Kriteria</th>
            <th>Bobot (%)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="text-center">1-3</td>
            <td>Sub-CPMK1: ……..</td>
            <td>
              <ul className="list-disc ml-4">
                <li>Indikator 1</li>
                <li>Indikator 2</li>
                <li>dst</li>
              </ul>
            </td>
            <td>
              <div className="font-bold">Topik I</div>
              <ul className="list-disc ml-4">
                <li>Sub-Topik I.1</li>
                <li>Sub-Topik I.2</li>
                <li>Dst</li>
              </ul>
            </td>
            <td>
              <ul className="list-disc ml-4">
                <li><span className="font-bold">Metode:</span> Case-Based Learning</li>
                <li><span className="font-bold">LMS:</span> Link GIFt-Learning atau yang lainnya</li>
              </ul>
            </td>
            <td>
              <ul className="list-disc ml-4">
                <li><span className="font-bold">TM</span> 2*50</li>
                <li><span className="font-bold">Mandiri</span> 2*60</li>
                <li><span className="font-bold">Tugas</span> 2*60</li>
              </ul>
            </td>
            <td>
              <ul className="list-disc ml-4">
                <li><span className="font-bold">Teknik:</span></li>
                <li><span className="font-bold">Kriteria:</span></li>
              </ul>
            </td>
            <td></td>
          </tr>
          <tr>
            <td className="text-center">4-5</td>
            <td>Sub-CPMK2: ……..</td>
            <td></td>
            <td></td>
            <td>Project-based learning</td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td className="text-center">dst</td>
            <td>dst</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default LessonPlan;
