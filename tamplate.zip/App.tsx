
import React from 'react';
import CoverPage from './components/CoverPage';
import TableOfContents from './components/TableOfContents';
import LearningAnalysis from './components/LearningAnalysis';
import RPSDescription from './components/RPSDescription';
import RPSDescriptionPart2 from './components/RPSDescriptionPart2';
import LessonPlan from './components/LessonPlan';
import TaskPlan from './components/TaskPlan';
import CPLAchievement from './components/CPLAchievement';
import GradingScale from './components/GradingScale';

const App: React.FC = () => {
  return (
    <div className="flex flex-col items-center">
      <div className="no-print fixed top-4 right-4 z-50">
        <button 
          onClick={() => window.print()}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full shadow-lg transition-all font-sans"
        >
          Cetak PDF
        </button>
      </div>

      <CoverPage />
      <div className="page-break" />
      
      <TableOfContents />
      <div className="page-break" />

      <LearningAnalysis />
      <div className="page-break" />

      <RPSDescription />
      <div className="page-break" />

      <RPSDescriptionPart2 />
      <div className="page-break" />

      <LessonPlan />
      <div className="page-break" />

      <TaskPlan taskNumber={1} />
      <div className="page-break" />

      <TaskPlan taskNumber={2} />
      <div className="page-break" />

      <TaskPlan taskNumber={3} />
      <div className="page-break" />

      <CPLAchievement />
      <div className="page-break" />

      <GradingScale />
    </div>
  );
};

export default App;
